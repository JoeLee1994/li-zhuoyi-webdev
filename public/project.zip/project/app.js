/**
 * Created by Joe on 2017/6/7.
 */
(function () {
    angular
        .module("Project", ['ngRoute'])
})();